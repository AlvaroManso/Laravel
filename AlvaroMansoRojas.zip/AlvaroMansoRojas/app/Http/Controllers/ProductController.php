<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index()
    {
    
        $products = Product::all();

        $title = 'Lista de Productos';


        return view('products.index', compact('title', 'products'));
    }

    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    public function create()
    {
        return view('products.create');
    }

    public function store()
    {
        $data = request()->validate([
            'tipo' => 'required',
            'marca' => 'required',
            'funcion' => 'required',
            'precio' => 'required',
        ], [
            'tipo.required' => 'El campo "tipo" es requerido'
        ]);

        Product::create([
            'tipo' => $data['tipo'],
            'marca' => $data['marca'],
            'funcion' => $data['funcion'],
            'precio' => $data['precio'],
        ]);

        return redirect()->route('products.index');
    }

    public function edit(Product $product)
    {
        return view('products.edit', ['product' => $product]);
    }

    public function update(Product $product)
    {
        $data = request()->validate([
            'tipo' => 'required',
            'marca' => 'required',
            'funcion' => 'required',
            'precio' => 'required',
        ]);

        $product->update($data);

        return redirect()->route('products.index', ['product' => $product]);
    }

    function destroy(Product $product)
    {
        $product->delete();

        return redirect()->route('products.index');
    }
}