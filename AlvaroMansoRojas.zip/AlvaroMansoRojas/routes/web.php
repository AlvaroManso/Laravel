<?php

Route::get('/', 'HomeController@index');

Route::get('/usuarios', 'UserController@index')
    ->name('users.index');

Route::get('/usuarios/{user}', 'UserController@show')
    ->where('user', '[0-9]+')
    ->name('users.show');

Route::get('/usuarios/nuevo', 'UserController@create')->name('users.create');

Route::post('/usuarios', 'UserController@store');

Route::get('/usuarios/{user}/editar', 'UserController@edit')->name('users.edit');

Route::put('/usuarios/{user}', 'UserController@update');

Route::delete('/users/{user}', 'UserController@destroy')->name('users.destroy');

Route::get('/products', 'ProductController@index')
    ->name('products.index')->middleware(['auth']);

Route::get('/products/{product}', 'ProductController@show')
    ->where('product', '[0-9]+')
    ->name('products.show')->middleware(['auth']);

Route::get('/products/new', 'ProductController@create')->name('products.create')->middleware(['auth']);

Route::post('/products', 'ProductController@store')->middleware(['auth']);

Route::get('/products/{product}/edit', 'ProductController@edit')->name('products.edit')->middleware(['auth']);

Route::put('/products/{product}', 'ProductController@update')->middleware(['auth']);

Route::delete('/products/{product}', 'ProductController@destroy')->name('products.destroy')->middleware(['auth']);

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');

Route::get('/home', 'HomeController@index')->name('home');

