<?php $__env->startSection('title', "Página no encontrada"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Página no encontrada</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\proyecto\resources\views/errors/404.blade.php ENDPATH**/ ?>