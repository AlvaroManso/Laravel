<?php $__env->startSection('title', "Producto {$product->id}"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Producto #<?php echo e($product->id); ?></h1>

    <p>Marca del producto: <?php echo e($product->marca); ?></p>
    <p>Modelo del producto: <?php echo e($product->modelo); ?></p>

    <p>
        <a href="<?php echo e(route('productos.index')); ?>">Regresar al listado de productos</a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\proyecto\resources\views/productos/show.blade.php ENDPATH**/ ?>