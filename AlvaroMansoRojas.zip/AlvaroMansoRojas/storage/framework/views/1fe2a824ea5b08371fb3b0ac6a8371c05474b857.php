<?php $__env->startSection('title', "Crear producto"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Editar producto</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url("products/{$product->id}")); ?>">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>


        <label for="tipo">Tipo:</label>
        <input type="text" name="tipo" id="tipo" placeholder="fertilizante" value="<?php echo e(old('tipo', $product->tipo)); ?>">
        <br>
        <label for="marca">Marca:</label>
        <input type="text" name="marca" id="marca" placeholder="GanjaWorld" value="<?php echo e(old('marca', $product->marca)); ?>">
        <br>
        <label for="funcion">Funcion:</label>
        <input type="text" name="funcion" id="funcion" placeholder="fertilizante" value="<?php echo e(old('funcion', $product->funcion)); ?>">
        <br>
        <label for="precio">Precio:</label>
        <input type="text" name="precio" id="precio" placeholder="50" value="<?php echo e(old('precio', $product->precio)); ?>">
        <button type="submit">Actualizar producto</button>
    </form>

    <p>
        <a href="<?php echo e(route('products.index')); ?>">Regresar al listado de productos</a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-master\resources\views/products/edit.blade.php ENDPATH**/ ?>