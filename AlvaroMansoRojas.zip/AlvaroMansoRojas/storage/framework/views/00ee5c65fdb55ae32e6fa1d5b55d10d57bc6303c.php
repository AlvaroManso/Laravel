<?php $__env->startSection('title', "Crear producto"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Crear producto</h4>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h6>Corrige los errores.</h6>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(url('products')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="tipo">Tipo:</label>
                    <input type="text" class="form-control" name="tipo" id="tipo" placeholder="fertilizante" value="<?php echo e(old('tipo')); ?>">
                </div>

                <div class="form-group">
                    <label for="marca">Marca:</label>
                    <input type="text" class="form-control" name="marca" id="marca" placeholder="Ganjaworld" value="<?php echo e(old('marca')); ?>">
                </div>

                <div class="form-group">
                    <label for="funcion">Funcion:</label>
                    <input type="text" class="form-control" name="funcion" id="funcion" placeholder="Fertilizante" value="<?php echo e(old('funcion')); ?>">
                </div>

                <div class="form-group">
                    <label for="precio">Precio:</label>
                    <input type="text" class="form-control" name="precio" id="precio" placeholder="50" value="<?php echo e(old('precio')); ?>">
                </div>

                <button type="submit" class="btn btn-primary">Añadir producto</button>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-link">Vuelve a la lista de productos</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-master\resources\views/products/create.blade.php ENDPATH**/ ?>