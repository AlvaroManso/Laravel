@extends('layout')

@section('title', "Producto {$product->id}")

@section('content')
    <h1>Producto #{{ $product->id }}</h1>

    <p>Marca del producto: {{ $product->marca }}</p>
    <p>Tipo de producto: {{ $product->tipo }}</p>

    <p>
        <a href="{{ route('products.index') }}">Vuelve a la lista de productos</a>
    </p>
@endsection