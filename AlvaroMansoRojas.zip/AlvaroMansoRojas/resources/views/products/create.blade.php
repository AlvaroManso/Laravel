@extends('layout')

@section('title', "Crear producto")

@section('content')
    <div class="card">
        <h4 class="card-header">Crear producto</h4>
        <div class="card-body">

            @if ($errors->any())
                <div class="alert alert-danger">
                    <h6>Corrige los errores.</h6>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ url('products') }}">
                {{ csrf_field() }}

                <div class="form-group">
                    <label for="tipo">Tipo:</label>
                    <input type="text" class="form-control" name="tipo" id="tipo" placeholder="fertilizante" value="{{ old('tipo') }}">
                </div>

                <div class="form-group">
                    <label for="marca">Marca:</label>
                    <input type="text" class="form-control" name="marca" id="marca" placeholder="Ganjaworld" value="{{ old('marca') }}">
                </div>

                <div class="form-group">
                    <label for="funcion">Funcion:</label>
                    <input type="text" class="form-control" name="funcion" id="funcion" placeholder="Fertilizante" value="{{ old('funcion') }}">
                </div>

                <div class="form-group">
                    <label for="precio">Precio:</label>
                    <input type="text" class="form-control" name="precio" id="precio" placeholder="50" value="{{ old('precio') }}">
                </div>

                <button type="submit" class="btn btn-primary">Añadir producto</button>
                <a href="{{ route('products.index') }}" class="btn btn-link">Vuelve a la lista de productos</a>
            </form>
        </div>
    </div>
@endsection