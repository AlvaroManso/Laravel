@extends('layout')

@section('title', "Crear producto")

@section('content')
    <h1>Editar producto</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ url("products/{$product->id}") }}">
        {{ method_field('PUT') }}
        {{ csrf_field() }}

        <label for="tipo">Tipo:</label>
        <input type="text" name="tipo" id="tipo" placeholder="fertilizante" value="{{ old('tipo', $product->tipo) }}">
        <br>
        <label for="marca">Marca:</label>
        <input type="text" name="marca" id="marca" placeholder="GanjaWorld" value="{{ old('marca', $product->marca) }}">
        <br>
        <label for="funcion">Funcion:</label>
        <input type="text" name="funcion" id="funcion" placeholder="fertilizante" value="{{ old('funcion', $product->funcion) }}">
        <br>
        <label for="precio">Precio:</label>
        <input type="text" name="precio" id="precio" placeholder="50" value="{{ old('precio', $product->precio) }}">
        <button type="submit">Actualizar producto</button>
    </form>

    <p>
        <a href="{{ route('products.index') }}">Regresar al listado de productos</a>
    </p>
@endsection