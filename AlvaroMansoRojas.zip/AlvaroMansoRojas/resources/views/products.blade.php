@extends('layouts.app')

@section('content')

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product List</title>
</head>

<body>
    <h1>{{ $title }}</h1>

    <hr>

    @empty($products)
    <p>No products listed.</p>

    @else
    <ul>
        @forelse ($products as $product)
            <li>{{ $product }}</li>
        @empty
            <li>No products listed.</li>
        @endforelse
    </ul>

</body>

@endsection